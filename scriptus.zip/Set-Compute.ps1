﻿Param (
    [Parameter(Mandatory=$true)][string]$MoRef,
    [Parameter(Mandatory=$false)][int]$MemoryGB,
    [Parameter(Mandatory=$false)][int]$NumCpu,
    [Parameter(Mandatory=$false)][int]$CoresPerSocket
)

# GET VM BY MOREF
$VM = (Get-VM -Id $MoRef)
if ($VM.Name -eq $null) {
    throw "No Virtual Machine found with MoRef: $($MoRef)"
}

# HANDLE INPUT AND SET PARAMETERS FOR SET-VM
if ($MemoryGB -gt 0 -and $NumCpu -eq 0 -and $CoresPerSocket -eq 0) {
    $SetVMParams = @{
        VM = $VM
        MemoryGB = $MemoryGB
    } 
} elseif ($MemoryGB -eq 0 -and $NumCpu -gt 0 -and $CoresPerSocket -gt 0) {
    $SetVMParams = @{
        VM = $VM
        NumCpu = $NumCpu
        CoresPerSocket = $CoresPerSocket
    }
} elseif ($MemoryGB -gt 0 -and $NumCpu -gt 0 -and $CoresPerSocket -gt 0) {
    $SetVMParams = @{
        VM = $VM
        MemoryGB = $MemoryGB
        NumCpu = $NumCpu
        CoresPerSocket = $CoresPerSocket
    }
} else {
    throw "SetVMCompute: Supply valid integer for either [MemoryGB] or [NumCpu,CoresPerSocket]"
}
    
# PERFORM COMPUTE CHANGE, RETURN RESULT, THROW FUNCTION IF SET-VM UNSUCCESSFUL
$SetVMResult = Invoke-Expression 'Set-VM @SetVMParams -Confirm:$false' -ErrorVariable ErrVar01
if ($SetVMResult.Id -ne $null) {
    return ($SetVMResult | select @{N="MoRef";E={$_.Id}},MemoryGB,NumCpu,CoresPerSocket | ConvertTo-Json -Depth 2 -Compress)
} else {
    throw "SetVMCompute: PowerCLI command 'Set-VM' was unsuccessful : " + $ErrVar01
}