﻿Param (
    [string]$Server,
    [string]$User,
    [string]$Password
)

# Connect
Set-PowerCLIConfiguration -Scope User -ParticipateInCEIP $false  -confirm:$false| Out-Null
Set-PowerCLIConfiguration -InvalidCertificateAction Ignore -DefaultVIServerMode Single -confirm:$false | Out-Null

$Connection = Connect-VIServer -Server $Server -User $User -Password $Password

return $Connection.SessionId | Out-String;