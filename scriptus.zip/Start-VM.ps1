﻿Param (
    [Parameter(Mandatory=$true)][String]$MoRef
)

$result = Get-VM -Id $MoRef | Start-VM;

return ConvertTo-Json @{

}