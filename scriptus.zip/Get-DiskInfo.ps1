﻿Param (
    [Parameter(Mandatory=$true)][String]$MoRef
)

# CHECK IF TEMPLATE AND GET DISK DATA
$VmView = Get-View -Id $MoRef -Property Config.Template
if ($VmView.MoRef -ne $null) {
    if ($VmView.Config.Template -eq $true) {
        $VmHardDisksViews = (Get-Template -Id $MoRef | Get-HardDisk).ExtensionData
    } else {
        $VmHardDisksViews = (Get-VM -Id $MoRef | Get-HardDisk).ExtensionData
    }
} else {
    throw "Unable to find Virtual Machine or Template with Id: $MoRef"
}

$DiskInfoDTO = @();
foreach ($HardDisk in $VmHardDisksViews) {
    # GET DATASTORE INFO AND CREATE DatastoreInfo
    $DatastoreView = Get-View -Id "$($HardDisk.Backing.Datastore)"
    $DatastoreInfo = @{
        UID = "$($DatastoreView.MoRef)"
        Name = $DatastoreView.Name
        Path = $DatastoreView.Summary.Url -replace "ds://",""
        Capacity = $DatastoreView.Summary.Capacity
        UsedCapacity = ($DatastoreView.Summary.Capacity - $DatastoreView.Summary.FreeSpace)
    }
    
    # CREATE DiskInfo
    $TempObj = @{
        OsDiskUID = $HardDisk.Backing.Uuid
        CloudDiskUID = $HardDisk.Backing.Uuid
        Capacity = $HardDisk.CapacityInBytes
        Datastore = $DatastoreInfo
        Filename = $HardDisk.Backing.FileName
    }

    $DiskInfoDTO += $TempObj
}

return ConvertTo-Json -Depth 3 -Compress $DiskInfoDTO