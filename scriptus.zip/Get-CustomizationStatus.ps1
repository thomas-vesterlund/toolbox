﻿Param (
    [Parameter(Mandatory=$true)][String]$MoRef
)

$VMView = Get-View -Id $MoRef

if ($VMView.Name -eq $null) {
    throw "GetCustomizationCompleteStatus: Get-VM failed for MoRef: $MoRef"
}

$HostName = ($VMView.Name.Split("."))[0]

return ConvertTo-Json @{
    IsComplete = $VMView.Guest.HostName -eq $HostName;
};