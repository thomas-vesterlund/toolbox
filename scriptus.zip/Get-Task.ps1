﻿Param (
    [Parameter(Mandatory=$true)][String]$Id
)
$Task = (Get-View -Id $Id).Info

if ($Task.Result -ne $null) {
    $TaskResult = "$($Task.Result)"
} else {
    $TaskResult = $null
}

if ("$($Task.Result)" -match "VirtualMachine-vm-") {
    $ResultUuid = (Get-View -Id "$($Task.Result)").Config.Uuid
} else {
    $ResultUuid = $null
}

return @{
    State = "$($Task.State)"
    Result = $TaskResult
    Progress = $Task.Progress
    Error = $Task.Error.LocalizedMessage
    ResultUuid = $ResultUuid
} | ConvertTo-Json -Depth 2