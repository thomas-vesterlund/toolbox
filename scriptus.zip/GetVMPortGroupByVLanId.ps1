﻿Param (
    [Parameter(Mandatory=$true)][String]$VMHostId,
    [Parameter(Mandatory=$true)][Int]$VLanId
)

$PortGroups = Get-VMHost -Id $VMHostId | Get-VirtualPortGroup | Where {$_.VLanId -eq $VLanId -or $_.Extensiondata.Config.DefaultPortCOnfig.Vlan.VlanId -eq $VLanId};

if ($PortGroups.Count -eq 1) {
    return ($PortGroups[0] | Select Name) | ConvertTo-Json -Compress -Depth 2
} elseif ($PortGroups.Count -eq 0) {
    throw "No virtual port groups were found with VLanId = $VLanId"
} else {
    throw "Multiple virtual port groups were found with VLanId = $VLanId"
}