﻿Param (
    [Parameter(Mandatory=$false)][string]$VMName,
    [Parameter(Mandatory=$false)][string]$Uuid,
    [Parameter(Mandatory=$false)][string]$MoRef
)

# HANDLE INPUT AND CREATE VIEW FILTER
$GetViewParams = @{
    Property = @(
        "Name",
        "Config.Uuid",
        "Runtime.Host"
    )
}
if ($VMName.Length -gt 0 -and $Uuid.Length -eq 0 -and $MoRef.Length -eq 0) {
    $NameFilter = "^" + $VMName + "$"
    $GetViewParams += @{Filter = @{"Name"=$NameFilter}}
    $GetViewParams += @{ViewType = "VirtualMachine"}
} elseif ($VMName.Length -eq 0 -and $Uuid.Length -gt 0 -and $MoRef.Length -eq 0) {
    $UuidFilter = "^" + $Uuid + "$"
    $GetViewParams += @{Filter = @{"Config.Uuid"=$UuidFilter}}
    $GetViewParams += @{ViewType = "VirtualMachine"}
} elseif ($VMName.Length -eq 0 -and $Uuid.Length -eq 0 -and $MoRef.Length -gt 0) {
    $GetViewParams.Add("Id", $MoRef)
} else {
    throw "GetMachineInfo: Supply a value for ONE of the following Parameters: VMName, Uuid, MoRef"
}

# GET VM-VIEW BASED ON FILTER INPUT
$VMView = Get-View @GetViewParams

# RETURN VM/TEMPLATE INFO IF FOUND, ELSE RETURN NULL
if ($VMView.Name -ne $null) {
    $Return = @{
        UID = $VMView.Config.Uuid
        Name = $VMView.Name
        VHostUID = $VMView.Runtime.Host.Value
        MoRef = "$($VMView.MoRef)"
    }
    return ($Return | ConvertTo-Json -Depth 2 -Compress)
} else {
    return $null
}