﻿Param (
    [Parameter(Mandatory=$true)][String]$VMUuid,
    [Parameter(Mandatory=$true)][String]$AdminPassword,
    [Parameter(Mandatory=$false)][array]$BackupRoutes
)

# GET VM OBJECT
#$VM = Get-VM | Where {$_.ExtensionData.Config.Uuid -eq $VMUuid}
$VM = Get-View -ViewType VirtualMachine -Filter @{"Config.Uuid"=$VMUuid} | Get-VIObjectByVIView
    if ($VM.Name -eq $null) {throw "SetLinuxOsConfig: Failed to get VM with Uuid: $VMUuid"}

# CREATE PASSWORD COMMAND STRING
$PasswordCommandString = 'echo -e "'
$PasswordCommandString += $AdminPassword
$PasswordCommandString += '\n'
$PasswordCommandString += $AdminPassword
$PasswordCommandString += '" | passwd administrator'

# CREATE COMMAND ARRAY
[System.Collections.ArrayList]$ShellCommands = @()

# CREATE BACKUP ROUTE COMMAND STRING
if ($BackupRoutes -ne $null -and $BackupRoutes[0].Gateway -as [IPAddress] -as [Bool]) {
    $RouteCommandString = 'echo "      routes:" | tee -a /etc/netplan/*.yaml'
    foreach ($BackupRoute in $BackupRoutes) {
        [string]$Prefix = NetmaskToPrefix -Netmask $BackupRoute.Netmask
        $RouteCommandString += '; echo "      - to: ' + $BackupRoute.Address + '/' + $Prefix + '" | tee -a /etc/netplan/*.yaml'
        $RouteCommandString += '; echo "        via: ' + $BackupRoute.Gateway + '" | tee -a -a /etc/netplan/*.yaml'
    }
    $RouteCommandString +='; sleep 1; netplan apply; '
    $ShellCommands.Add($RouteCommandString)
}

# ADD COMMANDS
if ($ShellCommands[0] -eq $null) {$ShellCommands.Add("")}
$ShellCommands[0] += $PasswordCommandString
$ShellCommands[0] += '; rm /etc/netplan/*.disabled'
$ShellCommands[0] += '; cat /dev/null > ~/.bash_history && history -c'

$ShellCommands.Add('passwd -dl root')

# APPLY SHELL COMMANDS
foreach ($ShellCommand in $ShellCommands) {
    Write-Host $ShellCommand
    Start-Sleep -Seconds 10
    Invoke-VMScript -VM $VM -GuestUser "root" -GuestPassword "TempRootPass" -ScriptText $ShellCommand
}