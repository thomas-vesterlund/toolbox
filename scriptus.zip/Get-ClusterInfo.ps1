﻿Param (
    [Parameter(Mandatory=$true)][String]$clusterUID
)

# GET CLUSTER RESOURCES
$Cluster = Get-Cluster -Id $clusterUID
$ClusterHosts = $Cluster | Get-VMHost

# CREATE HOST OBJECTS
$Hosts = @();
foreach ($ClusterHost in $ClusterHosts) {
    $TempHost = "" | select Name,UID,Cores,RAM,UsedRAM,Datastores
    $TempHost.Name = $ClusterHost.Name
    $TempHost.UID = $ClusterHost.ExtensionData.Hardware.SystemInfo.Uuid
    $TempHost.Cores = $ClusterHost.NumCpu
    [long]$TempHost.RAM = ($ClusterHost.MemoryTotalGB * 1024 * 1024 * 1024)
    [long]$TempHost.UsedRAM = ($ClusterHost.MemoryUsageGB * 1024 * 1024 * 1024)
    $TempHost.Datastores = @()

    # CREATE DATASTORE OBJECTS FOR CURRENT HOST
    $HostDatastores = $ClusterHost | Get-Datastore
    foreach ($HostDatastore in $HostDatastores) {
        $TempDatastore = "" | Select UID,Name,Path,Capacity,UsedCapacity
        $TempDatastore.UID = $HostDatastore.Id
        $TempDatastore.Name = $HostDatastore.Name
        $TempDatastore.Path = ""
        [long]$TempDatastore.Capacity = ($HostDatastore.CapacityGB * 1024 * 1024 * 1024)
        [long]$TempDatastore.UsedCapacity = ($HostDatastore.CapacityGB - $HostDatastore.FreeSpaceGB) * 1024 * 1024 * 1024

        $TempHost.Datastores += $TempDatastore
    }
    $Hosts += $TempHost
}

# CREATE CLUSTER DTO
$ClusterInfo = @{
    UID = $Cluster.Id
    Name = $Cluster.Name
    Hosts = $Hosts    
}

# RETURN AND EXPORT JSON TO FILE
return ($ClusterInfo | ConvertTo-Json -Depth 5 -Compress)