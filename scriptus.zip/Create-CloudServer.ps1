﻿Param (
    [Parameter(Mandatory=$true)][string]$clusterUID,
    [Parameter(Mandatory=$true)][string]$datastoreUID,
    [Parameter(Mandatory=$true)][string]$hostUID,
    [Parameter(Mandatory=$true)][string]$templateUID,
    [Parameter(Mandatory=$true)][string]$customerId,
    [Parameter(Mandatory=$true)][string]$companyName,
    [Parameter(Mandatory=$true)][int]$vlanId,
    [Parameter(Mandatory=$true)][string]$net,
    [Parameter(Mandatory=$true)][string]$ipAddress,
    [Parameter(Mandatory=$true)][string]$fqdn,
    [Parameter(Mandatory=$true)][string]$password,
    [Parameter(Mandatory=$true)][string]$netmask,
    [Parameter(Mandatory=$true)][string]$gateway,
    [Parameter(Mandatory=$true)][string[]]$dns,
    [Parameter(Mandatory=$true)][string]$os,
    [Parameter(Mandatory=$false)][object[]]$backupRoutes
)

$ErrorActionPreference = "Stop";

# GET PORT GROUP BY VLAN ID
Function GetVMPortGroupByVLanId {
    Param (
        [Parameter(Mandatory=$true)][String]$VMHostId,
        [Parameter(Mandatory=$true)][Int]$VLanId
    )

    # GET PORTGROUP BY VLAN ID, THROW IF NOT EXACTLY 1 RESULT
    $PortGroups = Get-VMHost -Id $VMHostId | Get-VirtualPortGroup | Where {$_.VLanId -eq $VLanId -or $_.Extensiondata.Config.DefaultPortCOnfig.Vlan.VlanId -eq $VLanId};
    if ($PortGroups.Count -eq 1) {
        return $PortGroups[0]
    } elseif ($PortGroups.Count -eq 0) {
        throw "No virtual port groups were found with VLanId = $VLanId"
    } else {
        throw "Multiple virtual port groups were found with VLanId = $VLanId"
    }
}

# GET FOLDER BY DATACENTER, CUSTOMER ID AND NET
Function GetVMFolder {
    Param (
        [Parameter(Mandatory=$true)][String]$DatacenterId,
        [Parameter(Mandatory=$true)][String]$CustomerId,
        [Parameter(Mandatory=$true)][String]$Net
    )

    # GET RESOURCES RECURSIVELY, THROW IF FAIL
    $Datacenter = Get-Datacenter -Id $DatacenterId
    if ($Datacenter.Name -ne $null) {
        $ParentFolder = $Datacenter | Get-Folder -Name $CustomerId
        if ($ParentFolder.Type -eq "VM") {
            $NetFolder = $ParentFolder | Get-Folder -Name "$($CustomerId)-$($Net)"
            if ($NetFolder.Type -eq "VM") {
                return $NetFolder
            } else {
                throw "Unable to find VM folder with Name: $($CustomerId)-$($Net) in folder with Name: $($CustomerId) in Datacenter: $($Datacenter.Name)"
            }
        } else {
            throw "Unable to find VM folder with Name: $($CustomerId) in Datacenter: $($Datacenter.Name)"
        }
    } else {
        throw "Unable to find Datacenter with Id $($DatacenterId)"
    }
}

# CREATE OS CUSTOMIZATION SPEC
Function NewOSSpec {
    Param (
        [Parameter(Mandatory=$true)][String]$OSType,
        [Parameter(Mandatory=$true)][String]$AdminPassword,
        [Parameter(Mandatory=$true)][String]$FQDN,
        [Parameter(Mandatory=$true)][array]$DnsServers,
        [Parameter(Mandatory=$false)][array]$BackupRoutes
    )

    # SEPARATE FQDN
    $HostName = ($FQDN.Split("."))[0]
    $DomainName = $FQDN -replace "^$($HostName)\.",""

    # CREATE GuiRunOnce FOR BACKUP ROUTES
    if ($BackupRoutes -ne $null -and $BackupRoutes[0].Gateway -as [IPAddress] -as [Bool]) {
        $GuiRunOnce = @()
        foreach ($BackupRoute in $BackupRoutes) {
            $GuiRunTemp = "route ADD $($BackupRoute.Address) MASK $($BackupRoute.Netmask) $($BackupRoute.Gateway)"
            $GuiRunOnce += $GuiRunTemp
        }
    }

    # CREATE OS SPEC
    if ($OSType -eq "Windows") {
        $NewSpecParams = @{
            OSType = "Windows"
            FullName = 'Administrator'
            OrgName = 'companyName'
            Workgroup = "WORKGROUP"
            NamingScheme = "Fixed"
            NamingPrefix = $HostName
            AdminPassword = $AdminPassword
            AutoLogonCount = 1
            Type = "NonPersistent"
        }
        if ($GuiRunOnce -ne $null) {$NewSpecParams.Add("GuiRunOnce",$GuiRunOnce)}

        $NewSpec = New-OSCustomizationSpec @NewSpecParams -ChangeSid -Confirm:$false
            if ($NewSpec.Name -eq $null) {throw "Failed to create New-OSCustomizationSpec"}

        return $NewSpec
    } elseif ($OSType -eq "Linux") {
        $NewSpecParams = @{
            OSType = "Linux"
            Domain = $DomainName
            DnsServer = $DnsServers
            Type = "NonPersistent"
            NamingScheme = "Fixed"
            NamingPrefix = $HostName
        }
        $NewSpec = New-OSCustomizationSpec @NewSpecParams -Confirm:$false
            if ($NewSpec.Name -eq $null) {throw "Failed to create New-OSCustomizationSpec"}

        return $NewSpec
    } else {
        throw "OS type not supported for New-OSCustomizationSpec"
    }
}

#####


# GET RESOURCES - THROW IF FAIL
$Cluster = Get-Cluster -Id $clusterUID
if ($Cluster.Name -eq $null) {throw "Could not find Cluster with Id: $($clusterUID)"}

$Datastore = Get-Datastore -Id $datastoreUID
if ($Datastore.Name -eq $null) {throw "Could not find Datastore with Id: $($datastoreUID)"}

$VMHost = Get-View -ViewType HostSystem -Filter @{"Hardware.SystemInfo.Uuid"=$hostUID} | Get-VIObjectByVIView
if ($VMHost.Name -eq $null) {throw "Could not find VMHost with Uuid: $hostUID"}

$Template = Get-Template | Where {$_.ExtensionData.Config.Uuid -eq $templateUID}
if ($Template.Name -eq $null) {throw "Unable to find Template with Uuid: $templateUID"}
if (($Template | Get-NetworkAdapter).ConnectionState.StartConnected -eq $true) {
    throw "Template $($Template.Name): NIC StartConnected is set to TRUE. It must be set to FALSE."
}

$VMPortGroup = GetVMPortGroupByVLanId -VMHostId $VMHost.Id -VLanId $vlanId
$Location = GetVMFolder -DatacenterId ($VMHost | Get-Datacenter).Id -CustomerId $customerId -Net $net
    
# MAKE OS CUSTOMIZATION FOR WINDOWS AND LINUX VMS, INCLUDING NIC SETTINGS
if ($os -eq "Windows" -or $os -eq "Linux") {
    $NewOSSpecParams = @{
        OSType = $os
        AdminPassword = $password
        FQDN = $fqdn
        DnsServers = $dns
    }
    if ($backupRoutes -ne $null -and $backupRoutes[0].Gateway -as [IPAddress] -as [Bool]) {
        $NewOSSpecParams.Add("BackupRoutes",$backupRoutes)
    }

    $OSCustomizationSpec = NewOSSpec @NewOSSpecParams
        
    $NicMappingParams = @{
        IpMode = "UseStaticIP"
        IPAddress = $ipAddress
        SubnetMask = $netmask
        DefaultGateway = $gateway
    }
    if ($os -eq "Windows") {$NicMappingParams.Add("Dns",$dns)}

    $NicMapping = $OSCustomizationSpec | Get-OSCustomizationNicMapping | Set-OSCustomizationNicMapping @NicMappingParams

        if ($NicMapping.IPAddress -eq $null) {throw "Failed to create New-OSCustomizationNicMapping for OSCustomizationSpec"}
}

# SET PARAMS FOR NEW VM
$NewVMParams = @{
    Name = $fqdn
    VMHost = $VMHost
    Datastore = $Datastore
    Portgroup = $VMPortGroup
    Template = $Template
    Location = $Location
}

# CREATE NEW VM
if ($os -eq "Windows" -or $os -eq "Linux") {
    $NewVMParams.OSCustomizationSpec = $OSCustomizationSpec
}

$NewVMTask = New-VM @NewVMParams -RunAsync # -WhatIf

return @{
    TaskId = $NewVMTask.Id.ToString();
    VmId = $NewVMTask.ObjectId.ToString();
}|ConvertTo-Json