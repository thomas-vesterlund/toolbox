﻿Param (
    [Parameter(Mandatory=$true)][String]$VMHostId,
    [Parameter(Mandatory=$true)][String]$VMId,
    [Parameter(Mandatory=$true)][String]$PortGroupName
)

if ( (Get-VM -Id $VMId | Get-VMHost).Id -ne $VMHostId) {
    throw "Virtual machine host ID does not match pre-check host ID"
}

$PortGroup =  Get-VMHost -Id $VMHostId | Get-VirtualPortGroup -Name $PortGroupName

if ($PortGroup.Count -eq 1) {
    $NetAdapter = (Get-VM -Id $VMId | Get-NetworkAdapter | select -First 1)
    Set-NetworkAdapter -NetworkAdapter $NetAdapter -Portgroup $PortGroup -Confirm:$false
    Set-NetworkAdapter -NetworkAdapter $NetAdapter -StartConnected:$true -Confirm:$false
    Set-NetworkAdapter -NetworkAdapter $NetAdapter -Connected:$true -Confirm:$false
} elseif ($PortGroup.Count -eq 0) {
    throw "No virtual port groups were found with Name = $PortGroupName"
} else {
    throw "Multiple virtual port groups were found with Name = $PortGroupName"
}