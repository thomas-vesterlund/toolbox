﻿Param (
    [Parameter(Mandatory=$true)][String]$MoRef
)

$result = Get-VM -Id $MoRef | Get-NetworkAdapter | Set-NetworkAdapter -StartConnected:$true -Confirm:$false;

return ConvertTo-Json @{}